"use client";

import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "motion/react";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Clock3,
  HeartPulse,
  LoaderCircle,
  LockKeyhole,
  Pencil,
  ShieldCheck,
  Stethoscope,
  UserRound,
} from "lucide-react";
import { toast } from "sonner";
import { BuaMark, PoweredBy } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

const emptyData = {
  submissionId: "",
  fullName: "",
  gender: "",
  age: "",
  phone: "",
  email: "",
  department: "",
  otherDepartment: "",
  conditions: [] as string[],
  otherCondition: "",
  medication: "",
  medicationDetails: "",
  smoking: "",
  alcohol: "",
  healthConcern: "",
  requestedService: "",
  medicalContact: "",
  wellnessInfo: "",
  consent: false,
};

type FormData = typeof emptyData;
type QuestionKey = keyof FormData | "summary" | "consentScreen";
type Question = {
  key: QuestionKey;
  section: "Personal" | "Employment" | "Health" | "Service" | "Communication" | "Review";
  eyebrow: string;
  title: string;
  help?: string;
  optional?: boolean;
};

const services = [
  ["Free Wellness Screening", "Free wellness screening", "Essential checks and a guided wellness review."],
  ["Standard Package", "Standard package", "Additional screening options available on the day."],
  ["Comprehensive Package", "Comprehensive package", "A broader assessment with the healthcare team."],
  ["Doctor Consultation Only", "Doctor consultation only", "Speak with a clinician about a specific concern."],
] as const;

const sectionMeta = [
  { name: "Personal", label: "Your details", icon: UserRound },
  { name: "Health", label: "Health background", icon: HeartPulse },
  { name: "Service", label: "Screening choice", icon: Stethoscope },
  { name: "Review", label: "Review & consent", icon: ShieldCheck },
] as const;

function Choice({
  group,
  value,
  label,
  description,
  compact = false,
}: {
  group: string;
  value: string;
  label: string;
  description?: string;
  compact?: boolean;
}) {
  const id = `${group}-${value}`.toLowerCase().replace(/[^a-z0-9]+/g, "-");
  return (
    <Label
      htmlFor={id}
      className={`group flex cursor-pointer items-center justify-between gap-4 rounded-xl border border-[#d9e0e7] bg-white transition hover:border-[#9eabb9] hover:bg-[#fbfcfd] has-[[data-state=checked]]:border-[#b5122b] has-[[data-state=checked]]:bg-[#fff7f8] ${
        compact ? "min-h-12 px-4 py-2.5" : "min-h-[58px] px-4 py-3"
      }`}
    >
      <span className="min-w-0">
        <span className="block text-[14px] font-bold tracking-[-.015em] text-[#1a2d44]">{label}</span>
        {description && <span className="mt-0.5 block text-[11px] leading-4 text-[#6d7a89]">{description}</span>}
      </span>
      <RadioGroupItem
        id={id}
        value={value}
        className="size-5 shrink-0 border-[#aab4bf] data-[state=checked]:border-[#b5122b] data-[state=checked]:text-[#b5122b]"
      />
    </Label>
  );
}

function SummaryBlock({
  title,
  rows,
  onEdit,
}: {
  title: string;
  rows: Array<[string, string]>;
  onEdit: () => void;
}) {
  return (
    <section className="rounded-2xl border border-[#dbe2e9] bg-white">
      <div className="flex items-center justify-between border-b border-[#e2e7ec] px-5 py-3">
        <h3 className="text-xs font-black uppercase tracking-[.12em] text-[#24405e]">{title}</h3>
        <button type="button" onClick={onEdit} className="inline-flex items-center gap-1.5 text-[11px] font-black text-[#2a67a5] hover:text-[#174f89]">
          <Pencil className="size-3" /> Edit
        </button>
      </div>
      <dl className="grid gap-x-6 px-5 py-2 sm:grid-cols-2">
        {rows.map(([label, value]) => (
          <div key={label} className="border-b border-[#edf0f3] py-2.5 last:border-b-0 sm:[&:nth-last-child(-n+2)]:border-b-0">
            <dt className="text-[9px] font-black uppercase tracking-[.12em] text-[#86909b]">{label}</dt>
            <dd className="mt-1 break-words text-xs font-bold leading-5 text-[#26394f]">{value || "Not provided"}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}

export default function RegisterPage() {
  const router = useRouter();
  const [index, setIndex] = useState(0);
  const [direction, setDirection] = useState(1);
  const [data, setData] = useState<FormData>(emptyData);
  const [hydrated, setHydrated] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    try {
      const saved = sessionStorage.getItem("bua-registration-draft");
      const restored = saved ? { ...emptyData, ...JSON.parse(saved) } : emptyData;
      setData({ ...restored, submissionId: restored.submissionId || crypto.randomUUID() });
    } catch {
      setData({ ...emptyData, submissionId: crypto.randomUUID() });
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) sessionStorage.setItem("bua-registration-draft", JSON.stringify(data));
  }, [data, hydrated]);

  const update = <K extends keyof FormData>(key: K, value: FormData[K]) =>
    setData((current) => ({ ...current, [key]: value }));

  const questions = useMemo<Question[]>(() => {
    const list: Question[] = [
      { key: "fullName", section: "Personal", eyebrow: "Your identity", title: "What is your full name?", help: "Enter it exactly as you would like it recorded." },
      { key: "gender", section: "Personal", eyebrow: "About you", title: "How would you describe your gender?" },
      { key: "age", section: "Personal", eyebrow: "About you", title: "How old are you?" },
      { key: "phone", section: "Personal", eyebrow: "Contact details", title: "What is your phone number?" },
      { key: "email", section: "Personal", eyebrow: "Contact details", title: "What is your email address?", help: "Required. Your registration number and private lookup code will be sent here." },
      { key: "department", section: "Employment", eyebrow: "Your work", title: "Which department do you work in?" },
    ];

    if (data.department === "Others") {
      list.push({ key: "otherDepartment", section: "Employment", eyebrow: "Your work", title: "Please enter your department." });
    }

    list.push({
      key: "conditions",
      section: "Health",
      eyebrow: "Health background",
      title: "Do you have any known medical conditions?",
      help: "Select all that apply, or choose None.",
    });

    if (data.conditions.includes("Others")) {
      list.push({ key: "otherCondition", section: "Health", eyebrow: "Health background", title: "What other condition should we record?" });
    }

    list.push({ key: "medication", section: "Health", eyebrow: "Medication", title: "Are you currently taking medication?" });

    if (data.medication === "Yes") {
      list.push({
        key: "medicationDetails",
        section: "Health",
        eyebrow: "Medication",
        title: "Which medication are you taking?",
        help: "List the names and any useful details.",
      });
    }

    list.push(
      { key: "smoking", section: "Health", eyebrow: "Lifestyle", title: "Do you currently smoke?" },
      { key: "alcohol", section: "Health", eyebrow: "Lifestyle", title: "Do you consume alcohol?" },
      { key: "healthConcern", section: "Health", eyebrow: "Your concern", title: "Is there a health concern you would like to discuss?", optional: true },
      { key: "requestedService", section: "Service", eyebrow: "Screening choice", title: "What would you like to access?" },
      {
        key: "medicalContact",
        section: "Communication",
        eyebrow: "Contact permission",
        title: "May the healthcare team contact you if further attention is required?",
        help: "This does not determine whether a referral is clinically required.",
      },
      {
        key: "wellnessInfo",
        section: "Communication",
        eyebrow: "Programme updates",
        title: "Would you like future wellness information?",
        help: "Choosing No will not affect your screening.",
      },
      { key: "summary", section: "Review", eyebrow: "Check your information", title: "Confirm that your details are correct." },
      { key: "consentScreen", section: "Review", eyebrow: "Final step", title: "Your consent is required to submit." },
    );
    return list;
  }, [data.department, data.conditions, data.medication]);

  useEffect(() => {
    if (index > questions.length - 1) setIndex(questions.length - 1);
  }, [index, questions.length]);

  const question = questions[index];
  const progress = ((index + 1) / questions.length) * 100;
  const currentSection =
    question?.section === "Employment" ? "Personal" :
    question?.section === "Communication" ? "Service" :
    question?.section;

  const error = useMemo(() => {
    if (!question) return "";
    switch (question.key) {
      case "fullName": return data.fullName.trim().length < 3 ? "Enter your full name." : "";
      case "gender": return !data.gender ? "Select one option." : "";
      case "age": return !data.age || Number(data.age) < 16 || Number(data.age) > 100 ? "Enter an age between 16 and 100." : "";
      case "phone": return data.phone.replace(/\D/g, "").length < 10 ? "Enter a valid phone number." : "";
      case "email": return !/^\S+@\S+\.\S+$/.test(data.email) ? "Enter a valid email address." : "";
      case "department": return !data.department ? "Select your department." : "";
      case "otherDepartment": return data.otherDepartment.trim().length < 2 ? "Enter your department." : "";
      case "otherCondition": return data.otherCondition.trim().length < 2 ? "Enter the condition." : "";
      case "medication": return !data.medication ? "Select one option." : "";
      case "medicationDetails": return data.medicationDetails.trim().length < 2 ? "Enter your medication details." : "";
      case "smoking": return !data.smoking ? "Select one option." : "";
      case "alcohol": return !data.alcohol ? "Select one option." : "";
      case "requestedService": return !data.requestedService ? "Select a service." : "";
      case "medicalContact": return !data.medicalContact ? "Select one option." : "";
      case "wellnessInfo": return !data.wellnessInfo ? "Select one option." : "";
      case "consentScreen": return !data.consent ? "You must accept the consent statement before submitting." : "";
      default: return "";
    }
  }, [data, question]);

  const move = (next: number) => {
    setDirection(next > index ? 1 : -1);
    setIndex(next);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const goToKey = (key: QuestionKey) => {
    const target = questions.findIndex((item) => item.key === key);
    if (target >= 0) move(target);
  };

  const next = () => {
    if (error) return toast.error(error);
    move(Math.min(index + 1, questions.length - 1));
  };

  const toggleCondition = (condition: string, checked: boolean) => {
    setData((current) => {
      if (condition === "None" && checked) return { ...current, conditions: ["None"], otherCondition: "" };
      const withoutNone = current.conditions.filter((item) => item !== "None");
      const nextValues = checked
        ? [...withoutNone.filter((item) => item !== condition), condition]
        : withoutNone.filter((item) => item !== condition);
      return {
        ...current,
        conditions: nextValues,
        otherCondition: condition === "Others" && !checked ? "" : current.otherCondition,
      };
    });
  };

  const submit = async () => {
    if (error) return toast.error(error);
    setSubmitting(true);

    try {
      const response = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (!response.ok) {
        const message =
          result.code === "SETUP_REQUIRED"
            ? "Registration is not available yet because the secure database setup is incomplete. Please notify an authorised administrator."
            : result.error || "Registration could not be completed.";
        throw new Error(message);
      }

      sessionStorage.removeItem("bua-registration-draft");
      sessionStorage.setItem(
        "bua-registration-result",
        JSON.stringify({
          ...result,
          firstName: data.fullName.trim().split(/\s+/)[0],
          email: data.email,
        }),
      );
      router.push("/registration-success");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Registration could not be completed.");
      setSubmitting(false);
    }
  };

  const answer = (() => {
    switch (question?.key) {
      case "fullName":
        return <Input autoFocus value={data.fullName} onChange={(e) => update("fullName", e.target.value)} placeholder="e.g. Ada Okafor" autoComplete="name" className="h-14 rounded-xl border-[#cfd7df] bg-white px-4 text-base shadow-none focus-visible:ring-[#2a67a5]" />;
      case "gender":
        return <RadioGroup className="grid gap-2 sm:grid-cols-3" value={data.gender} onValueChange={(v) => update("gender", v)}>{["Male", "Female", "Prefer not to say"].map((v) => <Choice key={v} group="gender" value={v} label={v} compact />)}</RadioGroup>;
      case "age":
        return <Input autoFocus type="number" min="16" max="100" inputMode="numeric" value={data.age} onChange={(e) => update("age", e.target.value)} placeholder="e.g. 35" className="h-14 max-w-[220px] rounded-xl border-[#cfd7df] bg-white px-4 text-xl font-black shadow-none focus-visible:ring-[#2a67a5]" />;
      case "phone":
        return <Input autoFocus type="tel" value={data.phone} onChange={(e) => update("phone", e.target.value)} placeholder="0801 234 5678" autoComplete="tel" className="h-14 rounded-xl border-[#cfd7df] bg-white px-4 text-base shadow-none focus-visible:ring-[#2a67a5]" />;
      case "email":
        return <Input autoFocus type="email" required value={data.email} onChange={(e) => update("email", e.target.value)} placeholder="name@example.com" autoComplete="email" className="h-14 rounded-xl border-[#cfd7df] bg-white px-4 text-base shadow-none focus-visible:ring-[#2a67a5]" />;
      case "department":
        return (
          <Select value={data.department} onValueChange={(v) => { update("department", v); if (v !== "Others") update("otherDepartment", ""); }}>
            <SelectTrigger className="h-14 rounded-xl border-[#cfd7df] bg-white px-4 text-sm shadow-none"><SelectValue placeholder="Select department" /></SelectTrigger>
            <SelectContent>{["Administration", "Finance", "Human Resources", "Procurement", "ICT", "Operations", "Others"].map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}</SelectContent>
          </Select>
        );
      case "otherDepartment":
        return <Input autoFocus value={data.otherDepartment} onChange={(e) => update("otherDepartment", e.target.value)} placeholder="Department name" className="h-14 rounded-xl border-[#cfd7df] bg-white px-4 text-base shadow-none focus-visible:ring-[#2a67a5]" />;
      case "conditions":
        return (
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            {["Hypertension", "Diabetes", "Asthma", "Heart Disease", "Kidney Disease", "High Cholesterol", "None", "Others"].map((value) => {
              const id = `condition-${value}`.toLowerCase().replace(/[^a-z0-9]+/g, "-");
              const selected = data.conditions.includes(value);
              return (
                <Label key={value} htmlFor={id} className={`flex min-h-12 cursor-pointer items-center justify-between gap-3 rounded-xl border px-3 py-2.5 text-xs font-bold transition ${selected ? "border-[#b5122b] bg-[#fff7f8] text-[#8f1025]" : "border-[#d9e0e7] bg-white text-[#2c3e53] hover:border-[#9eabb9]"}`}>
                  <span>{value}</span>
                  <Checkbox id={id} checked={selected} onCheckedChange={(checked) => toggleCondition(value, checked === true)} className="size-4.5" />
                </Label>
              );
            })}
          </div>
        );
      case "otherCondition":
        return <Input autoFocus value={data.otherCondition} onChange={(e) => update("otherCondition", e.target.value)} placeholder="Condition" className="h-14 rounded-xl border-[#cfd7df] bg-white px-4 text-base shadow-none focus-visible:ring-[#2a67a5]" />;
      case "medication":
        return <RadioGroup className="grid gap-2 sm:grid-cols-2" value={data.medication} onValueChange={(v) => { update("medication", v); if (v === "No") update("medicationDetails", ""); }}><Choice group="medication" value="Yes" label="Yes" compact /><Choice group="medication" value="No" label="No" compact /></RadioGroup>;
      case "medicationDetails":
        return <Textarea autoFocus value={data.medicationDetails} onChange={(e) => update("medicationDetails", e.target.value)} placeholder="Medication names and useful details" className="min-h-24 resize-none rounded-xl border-[#cfd7df] bg-white px-4 py-3 text-sm shadow-none focus-visible:ring-[#2a67a5]" />;
      case "smoking":
        return <RadioGroup className="grid gap-2 sm:grid-cols-3" value={data.smoking} onValueChange={(v) => update("smoking", v)}>{["Yes", "No", "Former smoker"].map((v) => <Choice key={v} group="smoking" value={v} label={v} compact />)}</RadioGroup>;
      case "alcohol":
        return <RadioGroup className="grid gap-2 sm:grid-cols-3" value={data.alcohol} onValueChange={(v) => update("alcohol", v)}>{["Yes", "Occasionally", "No"].map((v) => <Choice key={v} group="alcohol" value={v} label={v} compact />)}</RadioGroup>;
      case "healthConcern":
        return <Textarea autoFocus value={data.healthConcern} onChange={(e) => update("healthConcern", e.target.value)} maxLength={1200} placeholder="Share a brief concern" className="min-h-24 resize-none rounded-xl border-[#cfd7df] bg-white px-4 py-3 text-sm shadow-none focus-visible:ring-[#2a67a5]" />;
      case "requestedService":
        return <RadioGroup className="grid gap-2 sm:grid-cols-2" value={data.requestedService} onValueChange={(v) => update("requestedService", v)}>{services.map(([value, label, description]) => <Choice key={value} group="service" value={value} label={label} description={description} />)}</RadioGroup>;
      case "medicalContact":
        return <RadioGroup className="grid gap-2 sm:grid-cols-2" value={data.medicalContact} onValueChange={(v) => update("medicalContact", v)}><Choice group="medical-contact" value="Yes" label="Yes, you may contact me" compact /><Choice group="medical-contact" value="No" label="No, do not contact me" compact /></RadioGroup>;
      case "wellnessInfo":
        return <RadioGroup className="grid gap-2 sm:grid-cols-2" value={data.wellnessInfo} onValueChange={(v) => update("wellnessInfo", v)}><Choice group="wellness-info" value="Yes" label="Yes, keep me informed" compact /><Choice group="wellness-info" value="No" label="No, thank you" compact /></RadioGroup>;
      case "summary":
        return (
          <div className="grid gap-3 lg:grid-cols-2">
            <SummaryBlock
              title="Personal & work"
              onEdit={() => goToKey("fullName")}
              rows={[
                ["Full name", data.fullName],
                ["Gender & age", `${data.gender} · ${data.age}`],
                ["Phone", data.phone],
                ["Email", data.email],
                ["Department", data.department === "Others" ? data.otherDepartment : data.department],
              ]}
            />
            <SummaryBlock
              title="Health & screening"
              onEdit={() => goToKey("conditions")}
              rows={[
                ["Conditions", data.conditions.length ? data.conditions.join(", ") : "None selected"],
                ["Medication", data.medication === "Yes" ? data.medicationDetails : data.medication],
                ["Smoking", data.smoking],
                ["Alcohol", data.alcohol],
                ["Requested service", data.requestedService],
                ["Contact permissions", `Medical: ${data.medicalContact} · Wellness: ${data.wellnessInfo}`],
              ]}
            />
          </div>
        );
      case "consentScreen":
        return (
          <div className="rounded-2xl border border-[#dbe2e9] bg-white p-5 sm:p-6">
            <div className="flex items-start gap-4">
              <Checkbox id="consent-final" checked={data.consent} onCheckedChange={(checked) => update("consent", checked === true)} className="mt-1 size-5" />
              <Label htmlFor="consent-final" className="cursor-pointer">
                <strong className="block text-sm font-black text-[#1b2e44]">I consent to the use of my information for this outreach.</strong>
                <span className="mt-2 block text-xs leading-6 text-[#617083]">
                  I understand that my information will be used for BUA Health Outreach registration, authorised screening administration and necessary follow-up. I confirm that the information I provided is accurate to the best of my knowledge.
                </span>
              </Label>
            </div>
            <div className="mt-5 flex items-start gap-3 border-t border-[#e3e8ed] pt-4 text-[11px] leading-5 text-[#6c7887]">
              <LockKeyhole className="mt-0.5 size-4 shrink-0 text-[#2a67a5]" />
              Your private lookup code will not be shown to staff in plain text after registration.
            </div>
          </div>
        );
      default:
        return null;
    }
  })();

  return (
    <main className="min-h-[100dvh] bg-[#f2f5f8] text-[#162a42] lg:grid lg:grid-cols-[270px_1fr]">
      <aside className="relative hidden min-h-[100dvh] overflow-hidden bg-[#0d2949] text-white lg:sticky lg:top-0 lg:flex lg:h-[100dvh] lg:flex-col">
        <div className="relative z-10 p-7">
          <BuaMark inverse />
        </div>

        <div className="relative z-10 mt-7 px-7">
          <p className="text-[9px] font-black uppercase tracking-[.2em] text-[#7fb8e6]">Registration journey</p>
          <div className="mt-5 space-y-1">
            {sectionMeta.map(({ name, label, icon: Icon }) => {
              const active = currentSection === name;
              const currentIndex = sectionMeta.findIndex((item) => item.name === currentSection);
              const itemIndex = sectionMeta.findIndex((item) => item.name === name);
              const complete = itemIndex < currentIndex;
              return (
                <div key={name} className={`flex items-center gap-3 rounded-xl px-3 py-3 ${active ? "bg-white/10" : ""}`}>
                  <div className={`flex size-8 items-center justify-center rounded-lg ${active ? "bg-white text-[#0d2949]" : complete ? "bg-[#287a55] text-white" : "border border-white/15 text-white/45"}`}>
                    {complete ? <Check className="size-4" /> : <Icon className="size-4" />}
                  </div>
                  <div>
                    <p className={`text-xs font-black ${active ? "text-white" : "text-white/55"}`}>{label}</p>
                    {active && <p className="mt-1 text-[9px] font-bold uppercase tracking-[.12em] text-[#7fb8e6]">In progress</p>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="relative z-10 mt-auto p-7">
          <div className="relative mb-5 aspect-[4/3] overflow-hidden rounded-2xl">
            <Image src="/outreach/outreach-1.webp" alt="" fill className="object-cover" sizes="240px" />
            <div className="absolute inset-0 bg-[#0d2949]/22" />
          </div>
          <PoweredBy inverse />
        </div>
        <div className="absolute -bottom-32 -right-32 size-80 rounded-full border-[55px] border-white/[0.035]" />
      </aside>

      <section className="flex min-h-[100dvh] min-w-0 flex-col">
        <header className="sticky top-0 z-30 border-b border-[#dce3ea] bg-white/94 backdrop-blur-xl">
          <div className="mx-auto flex h-16 w-full max-w-[1080px] items-center justify-between px-4 sm:px-7">
            <div className="lg:hidden"><BuaMark compact /></div>
            <Button asChild variant="ghost" size="sm" className="hidden lg:inline-flex"><Link href="/"><ArrowLeft /> Exit registration</Link></Button>
            <div className="ml-auto flex items-center gap-2 text-[11px] font-bold text-[#637184]">
              <ShieldCheck className="size-4 text-[#2a67a5]" />
              Saved in this browser
            </div>
          </div>
          <div className="h-1 bg-[#e5e9ed]">
            <motion.div className="h-full bg-[#b5122b]" animate={{ width: `${progress}%` }} transition={{ duration: .25 }} />
          </div>
        </header>

        <div className="flex flex-1 items-center">
          <div className="mx-auto w-full max-w-[1080px] px-4 py-6 sm:px-7 lg:py-8">
            <div className="rounded-[22px] border border-[#dce3ea] bg-[#f9fafb] shadow-[0_18px_55px_rgba(20,42,66,.07)]">
              <div className="flex items-center justify-between border-b border-[#e0e6eb] px-5 py-3.5 sm:px-7">
                <span className="text-[9px] font-black uppercase tracking-[.18em] text-[#687789]">{question?.section}</span>
                <span className="text-[10px] font-black tabular-nums text-[#82909e]">{String(index + 1).padStart(2, "0")} / {String(questions.length).padStart(2, "0")}</span>
              </div>

              <div className="min-h-[440px] px-5 py-6 sm:px-7 sm:py-7 lg:min-h-[470px]">
                <AnimatePresence mode="wait" custom={direction}>
                  <motion.div
                    key={`${question?.key}-${index}`}
                    custom={direction}
                    initial={{ opacity: 0, x: direction * 14 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: direction * -10 }}
                    transition={{ duration: .2, ease: "easeOut" }}
                  >
                    <p className="text-[10px] font-black uppercase tracking-[.16em] text-[#b5122b]">{question?.eyebrow}</p>
                    <h1 className="mt-2 max-w-3xl text-balance text-[clamp(1.75rem,3.5vw,2.85rem)] font-black leading-[1.05] tracking-[-.045em] text-[#142a43]">{question?.title}</h1>
                    {question?.help && <p className="mt-3 max-w-2xl text-xs leading-6 text-[#657487]">{question.help}</p>}
                    {question?.optional && <span className="mt-3 inline-flex rounded-lg bg-[#e9edf1] px-2.5 py-1 text-[9px] font-black uppercase tracking-[.12em] text-[#687687]">Optional</span>}
                    <div className="mt-6">{answer}</div>
                  </motion.div>
                </AnimatePresence>

                {error && question?.key !== "summary" && (
                  <p className="mt-4 flex items-center gap-2 text-xs font-bold text-[#a3152c]">
                    <span className="size-1.5 rounded-full bg-[#b5122b]" /> {error}
                  </p>
                )}
              </div>

              <div className="flex items-center justify-between gap-3 border-t border-[#e0e6eb] bg-white px-4 py-3 sm:px-6">
                <Button type="button" variant="ghost" onClick={() => move(Math.max(0, index - 1))} disabled={index === 0}>
                  <ArrowLeft /> Back
                </Button>
                <div className="hidden items-center gap-2 text-[10px] font-bold text-[#788594] sm:flex">
                  <Clock3 className="size-3.5" /> Usually under 3 minutes
                </div>
                {question?.key === "consentScreen" ? (
                  <Button size="lg" onClick={submit} disabled={submitting}>
                    {submitting ? <><LoaderCircle className="animate-spin" /> Submitting…</> : <>Submit registration <ArrowRight /></>}
                  </Button>
                ) : (
                  <Button size="lg" onClick={next}>
                    {question?.key === "summary" ? "Continue to consent" : "Continue"} <ArrowRight />
                  </Button>
                )}
              </div>
            </div>

            <div className="mt-4 flex items-center justify-center gap-2 text-[10px] text-[#7a8795] lg:hidden">
              <ShieldCheck className="size-3.5 text-[#2a67a5]" /> Confidential participant experience
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
