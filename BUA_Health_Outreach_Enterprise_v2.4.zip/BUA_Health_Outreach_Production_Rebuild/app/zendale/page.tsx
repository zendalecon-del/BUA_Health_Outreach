import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  Building2,
  Check,
  HeartPulse,
  Landmark,
  MapPin,
  Network,
  Settings2,
  Stethoscope,
  UsersRound,
  Wrench,
} from "lucide-react";

const capabilities = [
  {
    number: "01",
    icon: Stethoscope,
    title: "Clinical & specialist healthcare",
    intro: "Coordinated access to everyday, specialist and advanced clinical care.",
    items: ["General medical services", "Specialist consultations", "Intensive care services (ICU)", "Endoscopy", "Diagnostics", "Telemedicine", "Preventive healthcare"],
  },
  {
    number: "02",
    icon: HeartPulse,
    title: "Fertility & women’s health",
    intro: "Specialist reproductive care supported by personalised clinical guidance.",
    items: ["Fertility assessment", "In-vitro fertilization (IVF)", "Assisted reproductive services", "Reproductive health"],
  },
  {
    number: "03",
    icon: UsersRound,
    title: "Corporate healthcare",
    intro: "Health programmes built around workforce needs and organisational priorities.",
    items: ["Corporate retainership", "Pre-employment medical screening", "Annual medical check-ups", "Executive medicals", "Occupational health services", "Workplace wellness programmes", "Nationwide healthcare support"],
  },
  {
    number: "04",
    icon: Wrench,
    title: "Medical technology solutions",
    intro: "End-to-end technical support for safe, reliable healthcare infrastructure.",
    items: ["Medical equipment procurement", "Installation", "Preventive maintenance", "Repairs", "Biomedical engineering support"],
  },
  {
    number: "05",
    icon: Settings2,
    title: "Healthcare consulting",
    intro: "Strategic and operational expertise for healthcare providers and investors.",
    items: ["Hospital planning & development", "Regulatory compliance", "Hospital quality improvement", "Operational advisory", "Public–Private Partnership support"],
  },
  {
    number: "06",
    icon: Network,
    title: "Hospital partnership & transformation",
    intro: "Partnership, management and transformation support that strengthens care delivery.",
    items: ["Strategic partnerships", "Management support", "Acquisitions", "Operational transformation"],
  },
];

const facilities = [
  {
    name: "Sky High Medical Centre",
    location: "5B Adekunle Banjo Street, Magodo Phase II, Shangisha, Lagos",
    category: "Multi-specialist care",
    description: "Comprehensive medical and surgical care, specialist clinics, diagnostics, corporate healthcare, retainership programmes and home care services.",
  },
  {
    name: "Sky High ICU Centre",
    location: "Mainland Hospital, Yaba, Lagos",
    category: "Critical care",
    description: "A dedicated intensive care facility for patients requiring life support, specialist monitoring and advanced medical management.",
  },
  {
    name: "Finnih Medical Centre",
    location: "Ikeja GRA, Lagos",
    category: "Primary & specialist care",
    description: "Accessible, patient-centred primary and specialist healthcare with a focus on quality care, prevention, diagnostics and corporate health.",
  },
  {
    name: "Lifecentre Medical Services",
    location: "Ikeja GRA • Ketu • Alimosho • Nationwide partner coverage",
    category: "Corporate healthcare",
    description: "Diagnostics, occupational health, preventive healthcare and corporate medical solutions delivered through facilities and a trusted partner network.",
  },
  {
    name: "Kindred Path Fertility Centre",
    location: "LASUTH, Ikeja, Lagos",
    category: "Fertility & women’s health",
    description: "Fertility assessment, assisted reproductive technology, IVF and personalised reproductive care through a strategic public-private partnership.",
  },
  {
    name: "Zendale Endoscopy Centre",
    location: "LASUTH, Ikeja, Lagos",
    category: "Specialist diagnostics",
    description: "Advanced diagnostic and therapeutic gastrointestinal procedures delivered by experienced specialists using modern endoscopic technology.",
  },
  {
    name: "Lifecentre Med Support",
    location: "LASUTH, Ikeja, Lagos",
    category: "Biomedical engineering",
    description: "Equipment procurement, installation, preventive maintenance, repairs, lifecycle management and technical support for healthcare institutions.",
  },
  {
    name: "VHELAR Consulting",
    location: "Lagos, Nigeria",
    category: "Healthcare advisory",
    description: "Hospital planning, regulatory compliance, quality improvement, operational advisory and PPP support for providers, investors and public institutions.",
  },
];

const reasons = [
  "One trusted partner for complete healthcare solutions",
  "Integrated network of specialist healthcare providers",
  "Corporate and occupational healthcare expertise",
  "Advanced medical technology and specialist services",
  "Healthcare consulting and hospital development expertise",
  "Nationwide coverage through a trusted partner network",
  "Strategic public and private sector partnerships",
  "Commitment to quality, innovation and patient-centred care",
];

export default function ZendalePage() {
  return (
    <main className="min-h-screen bg-[#f5f8fb] text-[#10243d]">
      <header className="sticky top-0 z-40 border-b border-[#dbe3ec] bg-white/92 backdrop-blur-xl">
        <div className="mx-auto flex h-[76px] max-w-[1480px] items-center justify-between px-5 sm:px-8 lg:px-10">
          <Link href="/zendale" className="inline-flex items-center gap-3" aria-label="Zendale Limited home">
            <Image src="/brand/zendale-logo.png" alt="Zendale Limited" width={46} height={48} className="h-10 w-auto object-contain" priority />
            <div>
              <p className="text-[15px] font-black tracking-[-.025em] text-[#143e70]">Zendale Limited</p>
              <p className="mt-1 text-[8px] font-bold uppercase tracking-[.23em] text-[#718095]">Integrated healthcare solutions</p>
            </div>
          </Link>
          <nav className="hidden items-center gap-6 text-xs font-bold text-[#59687a] lg:flex" aria-label="Zendale profile navigation">
            <a href="#capabilities" className="transition hover:text-[#174f89]">Capabilities</a>
            <a href="#network" className="transition hover:text-[#174f89]">Healthcare network</a>
            <a href="#partnerships" className="transition hover:text-[#174f89]">Partnerships</a>
          </nav>
          <div className="flex items-center gap-2">
            <Link href="/" className="hidden h-10 items-center rounded-xl border border-[#d5dde6] px-4 text-xs font-bold text-[#425269] transition hover:bg-[#f7f9fb] sm:inline-flex">BUA Outreach</Link>
            <a href="#contact" className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#154f89] px-4 text-xs font-black text-white transition hover:bg-[#103f70]">Partner with us <ArrowRight className="size-3.5" /></a>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden border-b border-[#dbe3ec] bg-white">
        <div className="absolute left-0 top-0 h-full w-[42%] bg-[#0d315b]" />
        <div className="absolute left-[42%] top-0 h-full w-px bg-[#dbe3ec]" />
        <div className="relative mx-auto grid min-h-[calc(100dvh-76px)] max-w-[1480px] lg:grid-cols-[.84fr_1.16fr]">
          <div className="relative flex items-end bg-[#0d315b] px-5 pb-10 pt-20 text-white sm:px-8 lg:px-10 lg:pb-14">
            <div className="absolute right-0 top-16 hidden h-[calc(100%-8rem)] w-12 border-y border-l border-white/10 lg:block" />
            <div className="relative max-w-xl">
              <p className="text-[10px] font-black uppercase tracking-[.22em] text-[#83bce9]">One partner. Complete healthcare solutions.</p>
              <h1 className="mt-5 text-balance text-[clamp(2.75rem,5.6vw,5.7rem)] font-black leading-[.92] tracking-[-.065em]">
                Healthcare, connected around real needs.
              </h1>
              <p className="mt-6 max-w-lg text-[15px] leading-7 text-white/68">
                Zendale brings clinical care, specialist services, medical technology, corporate health and healthcare advisory into one coordinated network.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <a href="#capabilities" className="inline-flex h-12 items-center gap-2 rounded-xl bg-white px-5 text-sm font-black text-[#0d315b] transition hover:-translate-y-0.5">Explore capabilities <ArrowRight className="size-4" /></a>
                <a href="#network" className="inline-flex h-12 items-center rounded-xl border border-white/24 px-5 text-sm font-bold text-white transition hover:bg-white/10">View our network</a>
              </div>
            </div>
          </div>

          <div className="relative min-h-[540px] bg-[#e7edf3] p-5 sm:p-8 lg:min-h-0 lg:p-10">
            <div className="relative h-full min-h-[520px] overflow-hidden rounded-[26px] shadow-[0_25px_70px_rgba(16,49,91,.18)]">
              <Image src="/outreach/outreach-4.webp" alt="Zendale healthcare team supporting participants" fill priority className="object-cover object-center" sizes="(min-width:1024px) 58vw, 100vw" />
              <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(8,31,58,.04),rgba(8,31,58,.58))]" />
              <div className="absolute bottom-5 left-5 right-5 grid gap-3 sm:grid-cols-3">
                {[
                  ["Clinical care", "Primary to specialist"],
                  ["Corporate health", "Workforce programmes"],
                  ["Health systems", "Technology & advisory"],
                ].map(([title, body]) => (
                  <div key={title} className="rounded-xl border border-white/20 bg-[#0b2d55]/78 p-4 text-white backdrop-blur-lg">
                    <p className="text-xs font-black">{title}</p>
                    <p className="mt-1 text-[10px] leading-4 text-white/58">{body}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="absolute right-3 top-1/2 hidden -translate-y-1/2 rotate-90 text-[8px] font-black uppercase tracking-[.28em] text-[#52708f] xl:block">Integrated by design</div>
          </div>
        </div>
      </section>

      <section className="bg-[#f5f8fb]">
        <div className="mx-auto grid max-w-[1480px] gap-12 px-5 py-16 sm:px-8 lg:grid-cols-[.72fr_1.28fr] lg:px-10 lg:py-24">
          <div>
            <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#1d659f]">About Zendale</p>
            <h2 className="mt-4 max-w-lg text-3xl font-black leading-tight tracking-[-.045em] sm:text-5xl">A healthcare company built as a connected system, not a single facility.</h2>
          </div>
          <div className="grid gap-8 text-[15px] leading-8 text-[#5b6a7c] md:grid-cols-2">
            <p>Zendale Limited is an integrated healthcare solutions company committed to transforming healthcare delivery through quality clinical services, specialist care, healthcare consulting, medical technology and corporate health solutions.</p>
            <p>Our model connects specialist institutions and strategic partnerships so individuals, organisations, healthcare providers and government institutions can access the right expertise through one trusted partner.</p>
            <p>We combine clinical excellence, healthcare innovation, operational experience and partnership development to improve healthcare access and outcomes across Nigeria.</p>
            <p>From advanced clinical care to hospital transformation, our role is to make complex healthcare needs easier to coordinate, implement and sustain.</p>
          </div>
        </div>
      </section>

      <section id="capabilities" className="border-y border-[#dbe3ec] bg-white">
        <div className="mx-auto max-w-[1480px] px-5 py-16 sm:px-8 lg:px-10 lg:py-24">
          <div className="grid gap-7 lg:grid-cols-[.7fr_1.3fr] lg:items-end">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#1d659f]">What we deliver</p>
              <h2 className="mt-4 text-3xl font-black tracking-[-.045em] sm:text-5xl">Six connected capabilities.</h2>
            </div>
            <p className="max-w-2xl text-sm leading-7 text-[#637286] lg:justify-self-end">A coordinated portfolio that supports care delivery, workforce health, medical technology and healthcare-system development.</p>
          </div>

          <div className="mt-12 border-t border-[#dbe3ec]">
            {capabilities.map(({ number, icon: Icon, title, intro, items }) => (
              <article key={number} className="grid gap-5 border-b border-[#dbe3ec] py-7 lg:grid-cols-[60px_260px_1fr] lg:items-start">
                <span className="text-[10px] font-black tracking-[.2em] text-[#2a67a5]">{number}</span>
                <div className="flex gap-3">
                  <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-[#eaf2fa] text-[#16588f]"><Icon className="size-5" /></div>
                  <div>
                    <h3 className="text-lg font-black tracking-[-.025em] text-[#172a42]">{title}</h3>
                    <p className="mt-2 text-xs leading-5 text-[#718094]">{intro}</p>
                  </div>
                </div>
                <div className="grid gap-x-8 gap-y-3 sm:grid-cols-2 xl:grid-cols-3">
                  {items.map((item) => (
                    <div key={item} className="flex items-start gap-2 text-xs leading-5 text-[#4f6074]"><Check className="mt-0.5 size-3.5 shrink-0 text-[#1c7a60]" />{item}</div>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="network" className="bg-[#0c294c] text-white">
        <div className="mx-auto grid max-w-[1480px] gap-12 px-5 py-16 sm:px-8 lg:grid-cols-[.65fr_1.35fr] lg:px-10 lg:py-24">
          <div className="lg:sticky lg:top-28 lg:self-start">
            <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#7db7e6]">The Zendale healthcare network</p>
            <h2 className="mt-4 max-w-md text-3xl font-black leading-tight tracking-[-.045em] sm:text-5xl">Specialist institutions. One coordinated network.</h2>
            <p className="mt-5 max-w-sm text-sm leading-7 text-white/58">Clinical care, critical care, fertility, endoscopy, medical technology and consulting connected through a single healthcare partner.</p>
            <div className="mt-8 flex items-center gap-3 border-t border-white/15 pt-5 text-xs font-bold text-white/65"><MapPin className="size-4 text-[#7db7e6]" /> Lagos base with nationwide partner coverage</div>
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            {facilities.map((facility, index) => (
              <article key={facility.name} className="group min-h-[245px] rounded-2xl border border-white/12 bg-white/[0.045] p-6 transition hover:-translate-y-0.5 hover:border-white/24 hover:bg-white/[0.07]">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-black tracking-[.18em] text-[#f2c230]">{String(index + 1).padStart(2, "0")}</span>
                  <span className="text-[9px] font-black uppercase tracking-[.14em] text-[#7db7e6]">{facility.category}</span>
                </div>
                <h3 className="mt-7 text-xl font-black tracking-[-.03em]">{facility.name}</h3>
                <p className="mt-2 flex items-start gap-2 text-[10px] font-bold uppercase tracking-[.08em] text-white/44"><MapPin className="mt-0.5 size-3 shrink-0" />{facility.location}</p>
                <p className="mt-5 text-xs leading-6 text-white/62">{facility.description}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="partnerships" className="bg-white">
        <div className="mx-auto grid max-w-[1480px] gap-10 px-5 py-16 sm:px-8 lg:grid-cols-[1.05fr_.95fr] lg:px-10 lg:py-24">
          <div className="relative min-h-[520px] overflow-hidden rounded-[26px]">
            <Image src="/outreach/outreach-3.webp" alt="Zendale team discussing healthcare options with participants" fill className="object-cover" sizes="(min-width:1024px) 52vw, 100vw" />
            <div className="absolute inset-0 bg-[linear-gradient(180deg,transparent_45%,rgba(8,30,56,.72))]" />
            <div className="absolute bottom-6 left-6 right-6 rounded-2xl border border-white/20 bg-[#0d315b]/78 p-5 text-white backdrop-blur-lg">
              <p className="text-[9px] font-black uppercase tracking-[.18em] text-[#8bc4ef]">Hospital partnership & transformation</p>
              <p className="mt-2 max-w-xl text-sm leading-6 text-white/76">We collaborate through strategic partnerships, management support, acquisitions and operational transformation to strengthen healthcare delivery.</p>
            </div>
          </div>
          <div className="flex flex-col justify-center">
            <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#1d659f]">Why Zendale</p>
            <h2 className="mt-4 text-3xl font-black tracking-[-.045em] sm:text-5xl">One accountable partner across the healthcare journey.</h2>
            <div className="mt-8 grid gap-3 sm:grid-cols-2">
              {reasons.map((reason) => (
                <div key={reason} className="flex items-start gap-3 border-t border-[#dbe3ec] pt-4 text-xs font-bold leading-5 text-[#41536a]">
                  <Check className="mt-0.5 size-4 shrink-0 text-[#1c7a60]" />
                  {reason}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="contact" className="border-t border-[#dbe3ec] bg-[#eaf1f7]">
        <div className="mx-auto grid max-w-[1480px] gap-10 px-5 py-16 sm:px-8 lg:grid-cols-[1.1fr_.9fr] lg:items-end lg:px-10 lg:py-20">
          <div>
            <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#1d659f]">Let’s partner with you</p>
            <h2 className="mt-4 max-w-3xl text-3xl font-black tracking-[-.045em] sm:text-5xl">Stronger healthcare systems. Healthier organisations. Healthier communities.</h2>
            <p className="mt-5 max-w-2xl text-sm leading-7 text-[#5e6d7f]">Whether you need specialist care, workforce health, medical equipment solutions, healthcare consulting or a hospital partnership, Zendale has the expertise and network to support you.</p>
          </div>
          <div className="rounded-2xl bg-[#0d315b] p-6 text-white sm:p-7">
            <p className="text-[9px] font-black uppercase tracking-[.18em] text-[#83bce9]">Zendale Limited</p>
            <div className="mt-5 grid gap-4 text-sm">
              <div className="flex items-start gap-3"><MapPin className="mt-0.5 size-4 text-[#83bce9]" /><div><p className="font-black">Lagos, Nigeria</p><p className="mt-1 text-xs text-white/50">Corporate office</p></div></div>
              <div className="flex items-start gap-3"><Building2 className="mt-0.5 size-4 text-[#83bce9]" /><div><p className="font-black">+234 XXX XXX XXXX</p><p className="mt-1 text-xs text-white/50">Phone placeholder</p></div></div>
              <div className="flex items-start gap-3"><Landmark className="mt-0.5 size-4 text-[#83bce9]" /><div><p className="font-black">contact@placeholder.com</p><p className="mt-1 text-xs text-white/50">Email placeholder</p></div></div>
            </div>
          </div>
        </div>
      </section>

      <footer className="bg-[#071a31] text-white">
        <div className="mx-auto flex max-w-[1480px] flex-col justify-between gap-6 px-5 py-7 sm:px-8 md:flex-row md:items-center lg:px-10">
          <div className="flex items-center gap-3">
            <Image src="/brand/zendale-logo.png" alt="Zendale Limited" width={42} height={44} className="h-9 w-auto object-contain" />
            <div><p className="text-sm font-black">Zendale Limited</p><p className="mt-1 text-[8px] font-bold uppercase tracking-[.2em] text-white/42">One Partner. Complete Healthcare Solutions.</p></div>
          </div>
          <div className="flex flex-wrap items-center gap-5 text-xs text-white/48">
            <Link href="/" className="transition hover:text-white">BUA Health Outreach</Link>
            <Link href="/lookup" className="transition hover:text-white">Participant lookup</Link>
            <Link href="/staff/login" className="transition hover:text-white">Authorised personnel</Link>
          </div>
        </div>
      </footer>
    </main>
  );
}
