import { NextResponse } from "next/server";
import { enforceRateLimit } from "@/lib/rate-limit";
import { createAdminClient } from "@/lib/supabase/admin";
import { generateLookupCode, hashLookupCode } from "@/lib/security";
import { registrationSchema } from "@/lib/validators";
import { sendRegistrationEmail } from "@/lib/email";
import { hasSupabaseConfig } from "@/lib/env";

function normalizePhone(value: string) {
  const digits = value.replace(/\D/g, "");
  if (digits.startsWith("234")) return `+${digits}`;
  if (digits.startsWith("0")) return `+234${digits.slice(1)}`;
  return `+234${digits}`;
}

function isSetupError(error: unknown) {
  const details = error && typeof error === "object" ? JSON.stringify(error) : String(error ?? "");
  return /PGRST205|42P01|relation .* does not exist|Could not find the table|schema cache/i.test(details);
}

function isCredentialError(error: unknown) {
  const details = error && typeof error === "object" ? JSON.stringify(error) : String(error ?? "");
  return /Invalid API key|JWT|service role|apikey|unauthorized/i.test(details);
}

export async function POST(request: Request) {
  const reference = `REG-${Date.now().toString(36).toUpperCase()}`;

  try {
    if (!hasSupabaseConfig()) {
      return NextResponse.json(
        {
          code: "SETUP_REQUIRED",
          error: "Registration is temporarily unavailable because the secure database connection has not been completed.",
          reference,
        },
        { status: 503 },
      );
    }

    if (!(await enforceRateLimit(request, "registration", 8, 15))) {
      return NextResponse.json({ error: "Too many attempts. Please wait and try again." }, { status: 429 });
    }

    const body = await request.json();
    const parsed = registrationSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message || "Please review the form." },
        { status: 400 },
      );
    }

    const input = parsed.data;
    const lookupCode = generateLookupCode();
    const lookupCodeHash = hashLookupCode(lookupCode);
    const db = createAdminClient();

    const payload = {
      submission_id: input.submissionId,
      lookup_code_hash: lookupCodeHash,
      full_name: input.fullName,
      gender: input.gender,
      age: input.age,
      phone: input.phone,
      phone_normalized: normalizePhone(input.phone),
      email: input.email,
      department: input.department,
      other_department: input.department === "Others" ? input.otherDepartment : null,
      medical_conditions: input.conditions,
      other_condition: input.conditions.includes("Others") ? input.otherCondition : null,
      taking_medication: input.medication === "Yes",
      medication_details: input.medication === "Yes" ? input.medicationDetails : null,
      smoking_status: input.smoking,
      alcohol_use: input.alcohol,
      health_concern: input.healthConcern || null,
      requested_service: input.requestedService,
      medical_contact_permission: input.medicalContact === "Yes",
      wellness_information_permission: input.wellnessInfo === "Yes",
      consent_accepted: true,
    };

    let { data: participant, error } = await db
      .from("participants")
      .insert(payload)
      .select("id, registration_number")
      .single();

    // A browser can retry the same request after a temporary network failure.
    // Reuse the existing registration and rotate its lookup code instead of failing.
    if (error?.code === "23505" && /submission_id/i.test(error.message || "")) {
      const existing = await db
        .from("participants")
        .select("id, registration_number")
        .eq("submission_id", input.submissionId)
        .single();

      if (!existing.error && existing.data) {
        const rotated = await db
          .from("participants")
          .update({ lookup_code_hash: lookupCodeHash, email: input.email })
          .eq("id", existing.data.id);

        if (!rotated.error) {
          participant = existing.data;
          error = null;
        }
      }
    }

    if (error || !participant) throw error || new Error("Registration was not saved.");

    let emailStatus: "sent" | "failed" | "not_configured" = "failed";

    try {
      const sent = await sendRegistrationEmail({
        to: input.email,
        firstName: input.fullName.split(/\s+/)[0],
        registrationNumber: participant.registration_number,
        lookupCode,
      });
      emailStatus = sent.status;

      await db.from("email_events").insert({
        email_type: "registration_confirmation",
        recipient: input.email,
        participant_id: participant.id,
        provider_message_id: "id" in sent ? sent.id : null,
        status: sent.status === "sent" ? "sent" : "failed",
      });
    } catch (emailError) {
      emailStatus = "failed";
      await db.from("email_events").insert({
        email_type: "registration_confirmation",
        recipient: input.email,
        participant_id: participant.id,
        status: "failed",
        error_code: emailError instanceof Error ? emailError.message.slice(0, 200) : "unknown",
      });
    }

    return NextResponse.json(
      {
        registrationNumber: participant.registration_number,
        lookupCode,
        emailStatus,
      },
      { status: 201 },
    );
  } catch (error) {
    console.error("Registration error", { reference, error });

    if (isSetupError(error)) {
      return NextResponse.json(
        {
          code: "SETUP_REQUIRED",
          error: "Registration is temporarily unavailable because the secure database tables have not been activated.",
          reference,
        },
        { status: 503 },
      );
    }

    if (isCredentialError(error)) {
      return NextResponse.json(
        {
          code: "CONFIGURATION_ERROR",
          error: "Registration is temporarily unavailable because the secure database credentials require attention.",
          reference,
        },
        { status: 503 },
      );
    }

    return NextResponse.json(
      {
        error: "We could not complete the registration. Please try again or speak with an authorised staff member.",
        reference,
      },
      { status: 500 },
    );
  }
}
