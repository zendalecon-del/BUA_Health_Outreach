import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  CheckCircle2,
  Clock3,
  FileKey2,
  LockKeyhole,
  ShieldCheck,
  Stethoscope,
} from "lucide-react";
import { BuaMark, PoweredBy } from "@/components/brand";

const programmeSteps = [
  { number: "01", title: "Register", body: "Complete a private guided form." },
  { number: "02", title: "Attend", body: "Present your registration number." },
  { number: "03", title: "Follow up", body: "Check approved results securely." },
];

export default function HomePage() {
  return (
    <main className="min-h-screen bg-[#f4f6f8] text-[#122238]">
      <header className="relative z-30 border-b border-[#dfe4ea] bg-white/90 backdrop-blur-xl">
        <div className="mx-auto flex h-[74px] max-w-[1480px] items-center justify-between px-5 sm:px-8 lg:px-10">
          <BuaMark />
          <nav className="flex items-center gap-2" aria-label="Public navigation">
            <Link
              href="/zendale"
              className="hidden px-3 py-2 text-xs font-bold text-[#536173] transition hover:text-[#113b6d] sm:inline-flex"
            >
              About Zendale
            </Link>
            <Link
              href="/lookup"
              className="inline-flex h-10 items-center gap-2 rounded-xl border border-[#d7dde4] bg-white px-4 text-xs font-bold text-[#334257] transition hover:border-[#aab5c2] hover:bg-[#f8fafc]"
            >
              <FileKey2 className="size-4 text-[#2a67a5]" />
              Check my record
            </Link>
            <Link
              href="/staff/login"
              className="hidden h-10 items-center rounded-xl bg-[#102a4a] px-4 text-xs font-bold text-white transition hover:bg-[#0b2039] md:inline-flex"
            >
              Staff access
            </Link>
          </nav>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.45] [background-image:linear-gradient(#dfe5eb_1px,transparent_1px),linear-gradient(90deg,#dfe5eb_1px,transparent_1px)] [background-size:72px_72px]" />
        <div className="absolute -left-48 top-24 size-[420px] rounded-full bg-[#b5122b]/[0.045] blur-3xl" />
        <div className="absolute -right-48 bottom-10 size-[480px] rounded-full bg-[#2a67a5]/[0.08] blur-3xl" />

        <div className="relative mx-auto grid min-h-[calc(100dvh-74px)] max-w-[1480px] items-center gap-8 px-5 py-8 sm:px-8 lg:grid-cols-[1.02fr_.98fr] lg:px-10 lg:py-10 xl:gap-14">
          <div className="flex min-w-0 flex-col justify-center py-4 lg:py-8">
            <div className="flex items-center gap-3 text-[11px] font-black uppercase tracking-[.18em] text-[#7a0d1f]">
              <span className="h-px w-9 bg-[#b5122b]" />
              BUA Employee Health Programme
            </div>

            <h1 className="mt-6 max-w-[720px] text-balance text-[clamp(2.65rem,5.4vw,5.15rem)] font-black leading-[.94] tracking-[-.065em] text-[#10243d]">
              A simpler way to begin your health screening.
            </h1>

            <p className="mt-6 max-w-[650px] text-[15px] leading-7 text-[#5b6878] sm:text-base sm:leading-8">
              Register privately before your BUA Health Outreach screening. Your registration number and secure lookup code will be sent to your email immediately after successful submission.
            </p>

            <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:items-center">
              <Link
                href="/register"
                className="group inline-flex h-14 items-center justify-center gap-3 rounded-xl bg-[#b5122b] px-7 text-sm font-black text-white shadow-[0_14px_34px_rgba(181,18,43,.22)] transition hover:-translate-y-0.5 hover:bg-[#981126]"
              >
                Begin registration
                <ArrowRight className="size-4 transition group-hover:translate-x-1" />
              </Link>
              <Link
                href="/lookup"
                className="inline-flex h-14 items-center justify-center gap-2 rounded-xl border border-[#cfd7df] bg-white px-6 text-sm font-bold text-[#25364b] transition hover:border-[#aeb9c5] hover:bg-[#fbfcfd]"
              >
                Already registered?
              </Link>
            </div>

            <div className="mt-8 grid gap-3 sm:grid-cols-3">
              <div className="flex items-start gap-3 border-l-2 border-[#b5122b] bg-white/70 px-4 py-3.5">
                <Clock3 className="mt-0.5 size-4 shrink-0 text-[#b5122b]" />
                <div>
                  <p className="text-xs font-black text-[#1b2e44]">About 3 minutes</p>
                  <p className="mt-1 text-[11px] leading-4 text-[#6c7886]">One clear question at a time.</p>
                </div>
              </div>
              <div className="flex items-start gap-3 border-l-2 border-[#2a67a5] bg-white/70 px-4 py-3.5">
                <LockKeyhole className="mt-0.5 size-4 shrink-0 text-[#2a67a5]" />
                <div>
                  <p className="text-xs font-black text-[#1b2e44]">Private by design</p>
                  <p className="mt-1 text-[11px] leading-4 text-[#6c7886]">Only authorised staff can access records.</p>
                </div>
              </div>
              <div className="flex items-start gap-3 border-l-2 border-[#d5a514] bg-white/70 px-4 py-3.5">
                <ShieldCheck className="mt-0.5 size-4 shrink-0 text-[#9c7710]" />
                <div>
                  <p className="text-xs font-black text-[#1b2e44]">No payment required</p>
                  <p className="mt-1 text-[11px] leading-4 text-[#6c7886]">Registration does not collect payment.</p>
                </div>
              </div>
            </div>

            <div className="mt-8 border-y border-[#d8dee5] bg-[#f8fafc]/85">
              <div className="grid sm:grid-cols-3">
                {programmeSteps.map((step, index) => (
                  <div
                    key={step.number}
                    className={`grid grid-cols-[34px_1fr] gap-3 px-3 py-4 sm:px-4 ${index < programmeSteps.length - 1 ? "border-b border-[#d8dee5] sm:border-b-0 sm:border-r" : ""}`}
                  >
                    <span className="text-[10px] font-black tracking-[.14em] text-[#b5122b]">{step.number}</span>
                    <div>
                      <p className="text-xs font-black text-[#1c2e43]">{step.title}</p>
                      <p className="mt-1 text-[11px] leading-4 text-[#6f7a87]">{step.body}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-[650px] lg:max-w-none">
            <div className="relative min-h-[510px] overflow-hidden rounded-[28px] bg-[#0f2948] shadow-[0_28px_90px_rgba(15,39,68,.22)] sm:min-h-[620px] lg:min-h-[min(72vh,690px)]">
              <Image
                src="/outreach/outreach-2.webp"
                alt="A Zendale healthcare professional supporting a BUA Health Outreach participant"
                fill
                priority
                className="object-cover object-center"
                sizes="(min-width:1024px) 48vw, 100vw"
              />
              <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(8,27,51,.05)_20%,rgba(8,27,51,.78)_100%)]" />

              <div className="absolute left-5 top-5 rounded-xl border border-white/25 bg-[#0d2848]/78 px-4 py-3 text-white backdrop-blur-xl sm:left-7 sm:top-7">
                <p className="text-[9px] font-black uppercase tracking-[.2em] text-white/55">Programme access</p>
                <p className="mt-1.5 text-sm font-black">BUA Health Outreach 2026</p>
              </div>

              <div className="absolute inset-x-5 bottom-5 rounded-2xl border border-white/20 bg-white/95 p-5 shadow-2xl backdrop-blur-xl sm:inset-x-7 sm:bottom-7 sm:p-6">
                <div className="flex items-center gap-3">
                  <div className="flex size-10 items-center justify-center rounded-xl bg-[#eef4fb] text-[#174e87]">
                    <Stethoscope className="size-5" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[.16em] text-[#768291]">After registration</p>
                    <h2 className="mt-1 text-base font-black tracking-[-.025em] text-[#172a42]">Keep both private identifiers safe.</h2>
                  </div>
                </div>
                <div className="mt-4 grid gap-2 sm:grid-cols-2">
                  <div className="flex items-center gap-2 rounded-xl bg-[#f3f5f7] px-3 py-2.5 text-xs font-bold text-[#394a5d]">
                    <CheckCircle2 className="size-4 text-[#287a55]" /> Registration number
                  </div>
                  <div className="flex items-center gap-2 rounded-xl bg-[#f3f5f7] px-3 py-2.5 text-xs font-bold text-[#394a5d]">
                    <CheckCircle2 className="size-4 text-[#287a55]" /> Private lookup code
                  </div>
                </div>
              </div>
            </div>

            <div className="absolute -bottom-4 -left-4 hidden w-[190px] overflow-hidden rounded-2xl border-4 border-[#f4f6f8] bg-white shadow-xl xl:block">
              <div className="relative aspect-[4/3]">
                <Image src="/outreach/outreach-4.webp" alt="Zendale outreach team" fill className="object-cover" sizes="190px" />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="border-y border-[#dce2e8] bg-white">
        <div className="mx-auto grid max-w-[1480px] gap-10 px-5 py-16 sm:px-8 lg:grid-cols-[.82fr_1.18fr] lg:px-10 lg:py-20">
          <div>
            <p className="text-[10px] font-black uppercase tracking-[.2em] text-[#2a67a5]">Before you register</p>
            <h2 className="mt-3 max-w-lg text-3xl font-black tracking-[-.045em] text-[#12243a] sm:text-4xl">Clear information before you share yours.</h2>
            <p className="mt-4 max-w-md text-sm leading-7 text-[#647182]">Your email address is required so the system can send your registration number and private lookup code.</p>
          </div>
          <div className="grid gap-px overflow-hidden rounded-2xl border border-[#dce2e8] bg-[#dce2e8] sm:grid-cols-2">
            {[
              ["What will staff see?", "Authorised staff can access the information needed for outreach administration and screening."],
              ["Should I share my code?", "No. Keep your lookup code private because it protects access to approved screening information."],
              ["Can I return later?", "Yes. Use your registration number and private lookup code on the participant lookup page."],
              ["Is this a payment form?", "No. This registration does not request or process payment."],
            ].map(([title, body]) => (
              <article key={title} className="bg-[#fafbfc] p-5 sm:p-6">
                <h3 className="text-sm font-black text-[#21344b]">{title}</h3>
                <p className="mt-2 text-xs leading-6 text-[#697687]">{body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <footer className="bg-[#0c223d] text-white">
        <div className="mx-auto flex max-w-[1480px] flex-col justify-between gap-6 px-5 py-7 sm:px-8 md:flex-row md:items-center lg:px-10">
          <BuaMark inverse />
          <div className="flex flex-col gap-3 md:items-end">
            <PoweredBy inverse />
            <div className="flex flex-wrap gap-5 text-xs text-white/50">
              <Link href="/zendale" className="transition hover:text-white">About Zendale</Link>
              <Link href="/lookup" className="transition hover:text-white">Participant lookup</Link>
              <Link href="/staff/login" className="transition hover:text-white">Authorised personnel</Link>
            </div>
          </div>
        </div>
      </footer>
    </main>
  );
}
